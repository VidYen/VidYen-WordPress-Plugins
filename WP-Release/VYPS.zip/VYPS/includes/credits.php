<?php
/*
 * Simple credits file to update the list so it doesn't have to be updated every time
  */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

 echo "<br><br>
	<h2>Here is a list of our other addons that go along with this system on our <a href=\"https://www.vidyen.com/vyps/\" target=\"_blank\">web site</a>:</h2>
	<p>VYPS AdScend Addon</p>
	<p>VYPS Coinhive Addon</p>
	<br><br>
	<h2>Coming Soon</h2>
	<p>VYPS Combat Game</p>
	<p>Leaderboard Addon</p>
	<p>VYPS CoinFlip Addon</p>
	";

/* You know I'm not entirely sure if the ending of this PHP will cause problems.
*  According to WP standards it's not needed.
*/
