<?php
// Silence is golden, but gold has no intrinsic value.
// At least it's easy to trade digital currencies.

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly