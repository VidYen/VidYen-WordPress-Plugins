# VidYen Points System Base Plugin

Description: VidYen Point System allows you to gamify monetization by giving your users a reason to turn off adblockers for rewards.
License: GPLv2 or later
  
Designer thoughts:
 
There are already many systems that if Frakensteined together will kind of do what I envisioned.
Yet it suprises me no one has made a gamification system for monetization (they have for engagment).
To be fair earn.gg does this, but he's not intended it to be shared with other admins.
However, I want Coin Hive (or a better altenrative) to become the future of micro-monetization.
The idea behind the VidYen Point system is to allow WordPress admins to track points from
their users and let them earn some type of awards. I was thinking Gift Cards through WooCommerce as
we already tested this and was popular but one could in theory use anything that you can stuff into
WooCommerce as a reward (images, songs, moviews, even plugins themselves. The goals is to shift
the world away from simply trying to make people watch ads (which is dying with the popularity of the
Brave Browser so if you intend to make a living through simply getting people to read your blog or video
and then click on an add for some odd reason, your going to be disapointed).
 
So... The idea is to get people to watch gamified ads or prefereable mine Coin Hive to monetize your site and you
(the site admin) give them a good reason to turn their ad blocker off. How you reward them is up to you,
but the VidYen point system is trying to help you track users when they do watch ads and give you a way
to reward that activity.

Good luck and godspeed!
 
-Felty
 
***Version 0.0.10***
-Basic point log.
-Basic manual adjustment (This is only in case you the admin want to make a change manually. Its not the intention of VidYen for you to use this as a way to run your site)
-Multiple currencies
-Prep-for addons to base package

 ***Version 0.0.20***
 -Shortcodes for balances (own plugin now)
 -Grammar fixes

***Goals for this plugin***
-Have decimal currencies
-Adjust for brevity
-Fix engrish for clarity


