# vidyen-wc-mmo

Plugin designed for MMO like rewards for WooCommerce.

Donate to our XMR Wallet:

8BpC2QJfjvoiXd8RZv3DhRWetG7ybGwD8eqG9MZoZyv7aHRhPzvrRF43UY1JbPdZHnEckPyR4dAoSSZazf5AY5SS9jrFAdb

Or if you have USD to throw around...

[Patreon](https://www.patreon.com/vidyen)

Patreon supports get free webhosting btw.

# Change Log

= 0.1.1 =

- Fixed font because of my OCD

= 0.1.0 =

- Release for Coin-Target

= 0.0.43 =

- Almost released.
