<?php
/**
*Plugin Name: Total point Balance
*Description: Total Points
**/

	function total_points()
	{
	}
	add_shortcode('examples','total_points');
